module CommonCode

def validate_params mandatory_params, input_data
    status, data = compare_request mandatory_params, input_data
    unless status
        return [false, data]
    end

    return [true, data]
end

def compare_request actual_obj,input_obj
    actual_obj.each do |key,value|
      if input_obj.has_key? key
          if input_obj[key].class != value
             return [false,error_resp(key,value)]
          end
      else
          return [false,error_resp(key)]
      end
    end
    return [true,{}]
end

def error_resp key,type=nil
    return "#{key} - Missing Parameter" if type.nil? 
    return "#{key} Should be #{type}" 
end

def get_error_response error_message, code
    error_response = {}
    error_response[:code] = code
    error_response[:message] = error_message
    resp = {}
    resp[:error] = error_response
    return resp
end

end
