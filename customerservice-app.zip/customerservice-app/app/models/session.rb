class Session < ApplicationRecord
include SessionsHelper
include CommonCode

belongs_to :agent


def validate_credentials params
	data = params["sessions"]

	pin = data["pin"]
	agent_id = data["user_id"]

	@agent = Agent.find_by_user_id(agent_id)
	if @agent.nil?
		return [false, get_error_response("User not found", "")]
	end
	
	if @agent.encrypted_password != BCrypt::Engine.hash_secret(pin, @agent.password_salt)	
		return [false, get_error_response("Invalid Password", "")]
	end

	return [true, {}]
end

def get_session_attributes params
	session = params["sessions"]
	data = {}
	data["session_id"] = SecureRandom.hex
	data["agent_id"] = @agent.id
	return data
end


def create params

    status, data = validate_params get_mandatory_params, params["sessions"]
    unless status
        return [true, data]
    end

	status, data = validate_credentials params
	unless status
		return [false, get_error_response(status, data)]
	end

	session_attributes = get_session_attributes params
	unless Session.create(session_attributes).valid?
		return [false, get_error_response("Failed to generate sessions", "")]
	end

	resp = {}
	resp["session_id"] = session_attributes["session_id"]
	resp["agent_id"] = @agent.user_id

	return [true, resp]
end

end
