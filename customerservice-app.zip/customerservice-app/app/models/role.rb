class Role < ApplicationRecord

has_many :rights
has_many :privileges, through: :rights

has_many :agent_roles
has_many :agents, through: :agent_roles


def construct_json
	data = []
	Role.all.each do |r1|
		d1 = {}
        d1["id"] = r1.id
		d1["title"] = r1.title
		d1["privileges"] = r1.privileges.as_json(:except => [:created_at, :updated_at])
		data << d1
	end
	return data
end

def lists params
    json_data = {"roles" => construct_json }

    return [true, json_data]
end

def rights params
    rights = params["rights"]
    role = Role.find(params["id"].to_i)
    role.privileges = rights["privileges"].map {|pr| Privilege.find(pr)}
    role.save

    d1 = {}
    d1["message"] = "Added privileges for role"

    return [true, d1]
end


end
