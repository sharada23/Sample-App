class UserSession < ApplicationRecord
include UserSessionsHelper
include CommonCode

belongs_to :user

def validate_credentials params
    data = params["user_sessions"]

    pin = data["pin"]
    user_id = data["user_id"]

    @user = User.find_by_user_id(user_id)
    if @user.nil?
        return [false, get_error_response("User not found", "")]
    end

    if @user.encrypted_password != BCrypt::Engine.hash_secret(pin, @user.password_salt)
        return [false, get_error_response("Invalid Password", "")]
    end

    return [true, {}]
end

def get_session_attributes params
    session = params["user_sessions"]
    data = {}
    data["session_id"] = SecureRandom.hex
    data["user_id"] = @user.id
    return data
end

def create params

    status, data = validate_params get_mandatory_params, params["user_sessions"]
    unless status
        return [true, data]
    end

    status, data = validate_credentials params
    unless status
        return [false, get_error_response(status, data)]
    end

    session_attributes = get_session_attributes params
    unless UserSession.create(session_attributes).valid?
        return [false, get_error_response("Failed to generate sessions", "")]
    end

    resp = {}
    resp["session_id"] = session_attributes["session_id"]
    resp["user_id"] = @user.user_id
	resp["message"] = "loggedin successfully"

    return [true, resp]
end

end
