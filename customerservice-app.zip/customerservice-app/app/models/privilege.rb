class Privilege < ApplicationRecord
include PrivilegesHelper
include CommonCode


has_many :rights
has_many :roles, through: :rights


def get_model_attributes params
	privileges = params["privileges"]

	data = {}
	data["title"] = privileges["title"]

	return data

end

def create params
    status, data = validate_params get_mandatory_params, params["privileges"]
    unless status
        return [false, data]
    end	

	attributes = get_model_attributes params
	unless Privilege.create(attributes).valid?
		return [false, get_error_response("failed to create privilege", "")]
	end

	resp = {}
	resp["message"] = "privilege created successfully"

	return [true, resp]

end

def construct_json
	data  = []
	Privilege.all.each do |pg|	
		d1 = {}
        d1["id"] = pg.id
		d1["title"] = pg.title
		data << d1
	end
	return data
end

def index params
	json_data = {"privilege" => construct_json}
	return [true, json_data]
end


end
