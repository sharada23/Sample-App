class User < ApplicationRecord
include UsersHelper
include CommonCode

has_many :tickets,  dependent: :delete_all
has_many :user_sessions,  dependent: :delete_all


before_save :save_user
validates_uniqueness_of :user_id

def save_user
    password = self.pin
    self.password_salt = BCrypt::Engine.generate_salt
    self.encrypted_password = BCrypt::Engine.hash_secret(password, password_salt)
end

def get_model_attributes params
	user = params["users"]
	data = {}
	data["user_id"] = user["user_id"]
	data["first_name"] = user["first_name"]
	data["last_name"] = user["last_name"]
	data["pin"] = user["pin"]

	data
end

def create params
	status, data = validate_params get_mandatory_params, params["users"]
	unless status
		return [true, data]
	end

	user_attributes = get_model_attributes params
	unless User.create(user_attributes).valid?
		return [false, get_error_response("failed to create user", "")]
	end

	d1 = {}
	d1["user_sessions"] = {}
	d1["user_sessions"]["user_id"] = user_attributes["user_id"]
	d1["user_sessions"]["pin"] = user_attributes["pin"]
	status, data = UserSession.new.create d1
	unless status
		return [false, get_error_response("failed to generate session", "")]
	end

	resp = {}
	resp["message"] = "user created successfully"
	resp["session_id"] = data["session_id"]

	return [true, resp]
	
end

def construct_json

    data = []
    User.all.each do |us|
        d1 = {}
		d1["id"] = us.id
        d1["user_id"] = us.user_id
        d1["first_name"] = us.first_name
        d1["last_name"] = us.last_name
        data << d1
    end

    return data
end

def index params

    json_data = {"users" => construct_json }

    return [true, json_data]
end


def show params
	user_id = params["id"].to_i
	user = User.find(user_id)
	d1 = {"id"=> user.id, "user_id" => user.user_id, "first_name" => user.first_name, "last_name" => user.last_name, "created_at"=>user.created_at}

	return [true, d1]
end

end
