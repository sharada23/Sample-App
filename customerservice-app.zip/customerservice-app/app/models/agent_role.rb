class AgentRole < ApplicationRecord


belongs_to :agent
belongs_to :role

end
