class Agent < ApplicationRecord
include AgentsHelper
include CommonCode

has_many :sessions,  dependent: :delete_all

has_one :agent_role,  dependent: :delete
has_one :role, through: :agent_role

before_save :save_user
validates_uniqueness_of :user_id
validates_uniqueness_of :agent_id

def save_user
    password = self.pin
    self.password_salt = BCrypt::Engine.generate_salt
    self.encrypted_password = BCrypt::Engine.hash_secret(password, password_salt)
end

def get_user_attributes params
    agent = params["agents"]
    data = {}
    data["user_id"] = agent["user_id"]
	data["agent_id"] = Time.now.nsec.to_s
    data["first_name"] = agent["first_name"]
    data["last_name"] = agent["last_name"]
    data["pin"] = agent["pin"]

    data
end

def create params
    status, data = validate_params get_mandatory_params, params["agents"]
    unless status
        return [true, data]
    end

    user_attributes = get_user_attributes params
    unless Agent.create(user_attributes).valid?
        return [false, {"errors"=> {"message"=> "failed to create user"}}]
    end

    resp = {}
    resp["message"] = "user created successfully"

    return [true, resp]

end

def construct_json

	data = []
	Agent.all.each do |ag|
		d1 = {}
		d1["user_id"] = ag.user_id
		d1["first_name"] = ag.first_name
		d1["last_name"] = ag.last_name
        d1["role"] = ag.role.as_json(:except => [:created_at, :updated_at])
		data << d1
	end

	return data
end

def index params

	json_data = {"agents" => construct_json	}

	return [true, json_data]
end

end
