class Ticket < ApplicationRecord
include TicketsHelper
include CommonCode

belongs_to :user


def get_model_attributes params
	tickets = params["tickets"]

	data = {}
	data["title"] = tickets["title"] if tickets["title"].present?
	data["image"] = tickets["image"] if tickets["image"].present?
	data["category"] = tickets["category"] if tickets["category"].present?
	data["comments"] = tickets["comments"] if tickets["comments"].present?
	data["user_id"] = UserSession.find_by_session_id(params["user_session_id"]).user_id

	data

end

def create params
    status, data = validate_params get_mandatory_params, params["tickets"]
    unless status
        return [false, get_error_response(data,"")]
    end


    attributes = get_model_attributes params
    unless Ticket.create(attributes).valid?
        return [false, get_error_response("failed to create privilege", "")]
    end

	d1 = {}
	d1["message"] = "ticket created successfully"

	return [true, d1]
end

def update params
	ticket_id = params[:id]
	ticket = Ticket.find(ticket_id)
	if ticket.nil?
		return [false, get_error_response("ticket not found", "")]
	end

	attributes = get_model_attributes params
	attributes["agent_id"] = Session.find_by_session_id(params[:session_id]).agent_id
	unless ticket.update_attributes(attributes).valid?
		return [false, get_error_response("Failed to update ticket", "")]
	end

	d1 = {}
	d1["message"] = "ticket updated successfully"

	return [true, d1]
end


def construct_json
    data = []
    Ticket.all.each do |t1|
        d1 = {}
		d1["id"] = t1.id
        d1["title"] = t1.title
		d1["image"] = t1.image
		d1["category"] = t1.category
		d1["comments"] = t1.comments
		d1["status"] = t1.status
        data << d1
    end
    return data
end

def lists params
    json_data = {"tickets" => construct_json }

    return [true, json_data]
end

def construct_user_tickets_json tickets
    data = []
    tickets.all.each do |t1|
        d1 = {}
		d1["id"] = t1.id
        d1["title"] = t1.title
		d1["image"] = t1.image
		d1["category"] = t1.category
		d1["comments"] = t1.comments
		d1["status"] = t1.status
        data << d1
    end
    return data

end


def index params
	session_id = params["user_session_id"]

	us = UserSession.find_by_session_id(session_id)
	tickets = us.user.tickets

    json_data = {"tickets" => construct_user_tickets_json(tickets) }

    return [true, json_data]

end

def process params

	t_id = params["ticket_id"].to_i

	ticket = Ticket.find(t_id)
	ticket.category = params["tickets"]["category"]
	ticket.status = true
	ticket.save

	return [true, {"message"=>"ticket process successfully"}]

end

end
