class ApplicationController < ActionController::Base
  include CommonCode
  before_action :set_access, :allow_cors, :allow_all_request
  protect_from_forgery with: :exception
  skip_before_action :verify_authenticity_token

def allow_all_request
#	logger.debug "-------1-----#{request.inspect}--------\n#{response.inspect}-"
	logger.debug "-------1------"
    request.headers["Access-Control-Allow-Origin"] = "*"
    request.headers["Access-Control-Allow-Methods"] = "*"
    request.headers["Access-Control-Request-Method"] = "*"
    request.headers['Access-Control-Allow-Headers'] = 'Origin, X-Requested-With, Content-Type, Accept, Authorization'
end

def allow_cors
#	logger.debug "--------2-----#{request.inspect}--------\n#{response.inspect}---"
  headers["Access-Control-Allow-Origin"] = "*"
  headers["Access-Control-Allow-Methods"] = %w{GET POST PUT DELETE}.join(",")
  headers["Access-Control-Allow-Headers"] = %w{Origin Accept Content-Type X-Requested-With X-CSRF-Token}.join(",")
  head(:ok) if request.request_method == "OPTIONS"
  # or, render text: ''
  # if that's more your style
end

def set_access
#	logger.debug "--------3-----#{request.inspect}--------\n#{response.inspect}---"
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Methods"] = "*"
    response.headers["Access-Control-Request-Method"] = "*"
    response.headers['Access-Control-Allow-Headers'] = 'Origin, X-Requested-With, Content-Type, Accept, Authorization'
end

  before_filter :validate_auth_token  
  before_filter :set_access

def set_access
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Methods"] = "*"
    response.headers["Access-Control-Request-Method"] = "*"
    response.headers['Access-Control-Allow-Headers'] = 'Origin, X-Requested-With, Content-Type, Accept, Authorization'
end

def validate_auth_token
    return true
end

def validate_session
    unless params.has_key?"user_session_id"
        render json: get_error_response("user_session_id is not present", "")
        return
    end

    s = UserSession.find_by_session_id(session_id)
    if s.blank?
        render json: get_error_response("Invalid session", "")
        return
    end

	params["session_obj"] = s
	return params

end

def authorize
	unless params.has_key?"session_id"
		render json: get_error_response("session_id is not present", "")
		return
	end
	controller = params[:controller]
	action = params[:action]
	session_id = params[:session_id]

	s = Session.find_by_session_id(session_id)
	if s.blank?
		render json: get_error_response("Invalid session", "")
		return
	end

	title = controller + "_" + action
	privilege = s.user.role.privilege.find_by_title(title)
	unless privilege.present?
		render json: get_error_response("Action not allowed", "")
		return 
	end
	
	return true
end


end
