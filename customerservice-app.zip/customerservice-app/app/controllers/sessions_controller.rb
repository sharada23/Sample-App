class SessionsController < ApplicationController

def create
	s = Session.new
	status, data = s.create params
	if status
		render json: data, status: :ok
	else 
		render json: data, status: :unprocessable_entity
	end
end


end
