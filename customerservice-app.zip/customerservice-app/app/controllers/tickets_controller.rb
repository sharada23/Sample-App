class TicketsController < ApplicationController

def create
	ticket = Ticket.new
    status, data = ticket.create params
    if status
        render json: data, status: :ok
    else
        render json: data, status: :unprocessable_entity
    end
end

def process_ticket
    ticket = Ticket.new
    status, data = ticket.process params
    if status
        render json: data, status: :ok
    else
        render json: data, status: :unprocessable_entity
    end
end


def lists
    ticket = Ticket.new
    status, data = ticket.lists params
    if status
        render json: data, status: :ok
    else
        render json: data, status: :unprocessable_entity
    end
end

def index
	ticket = Ticket.new
    status, data = ticket.index params
    if status
        render json: data, status: :ok
    else
        render json: data, status: :unprocessable_entity
    end
end

end
