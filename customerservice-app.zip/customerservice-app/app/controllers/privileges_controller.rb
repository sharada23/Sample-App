class PrivilegesController < ApplicationController

def create
    privilege = Privilege.new
    status, data = privilege.create params
    if status
        render json: data, status: :ok
    else
        render json: data, status: :unprocessable_entity
    end
end

def index
    privilege = Privilege.new
    status, data = privilege.index params
    if status
        render json: data, status: :ok
    else
        render json: data, status: :unprocessable_entity
    end
end

end
