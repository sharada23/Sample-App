class AgentsController < ApplicationController
include CommonCode

before_filter :authorize, :only => ["register"]


def sum
	a = params["a"].to_i
	b = params["b"].to_i
	render json: a+b, status: :ok
end

def create
    agent = Agent.new
    status, data = agent.create params
    if status
        render json: data, status: :ok
    else
        render json: data, status: :unprocessable_entity
    end
end

def index
    agent = Agent.new
    status, data = agent.index params
    if status
        render json: data, status: :ok
    else
        render json: data, status: :unprocessable_entity
    end
end

def register
    agent = Agent.new
    status, data = agent.create params
    if status
        render json: data, status: :ok
    else
        render json: data, status: :unprocessable_entity
    end

end

end
