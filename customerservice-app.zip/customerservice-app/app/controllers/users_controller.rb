class UsersController < ApplicationController


def create
	user = User.new
	status, data = user.create params
	if status
		render json: data, status: :ok
	else
		render json: data, status: :unprocessable_entity
	end
end

def index
    user = User.new
    status, data = user.index params
    if status
        render json: data, status: :ok
    else
        render json: data, status: :unprocessable_entity
    end
end

def show
    user = User.new
    status, data = user.show params
    if status
        render json: data, status: :ok
    else
        render json: data, status: :unprocessable_entity
    end
end

end
