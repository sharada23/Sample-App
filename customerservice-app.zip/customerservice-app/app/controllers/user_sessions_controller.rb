class UserSessionsController < ApplicationController

#before_filter :validate_session, :only => ["create"]

def create
    us = UserSession.new
    status, data = us.create params
    if status
        render json: data, status: :ok
    else
        render json: data, status: :unprocessable_entity
    end
end


end
