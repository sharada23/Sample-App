class RolesController < ApplicationController

def rights
    role = Role.new
    status, data = role.rights params
    if status
        render json: data, status: :ok
    else
        render json: data, status: :unprocessable_entity
    end
end


def lists
    role = Role.new
    status, data = role.lists params
    if status
        render json: data, status: :ok
    else
        render json: data, status: :unprocessable_entity
    end
end


end
