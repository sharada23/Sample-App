module TicketsHelper

def get_mandatory_params
#	{"title"=>String, "image"=> String, "category"=> String, "comments" => String}
	return {"title"=>String, "comments" => String}
end

end
