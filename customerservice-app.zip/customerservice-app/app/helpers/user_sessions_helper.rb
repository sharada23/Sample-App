module UserSessionsHelper

def get_mandatory_params
    {"user_id"=>String, "pin"=>String}
end

end
