module PrivilegesHelper

def get_mandatory_params
	{"title" => String}
end

end
