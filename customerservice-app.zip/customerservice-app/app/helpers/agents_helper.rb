module AgentsHelper

def get_mandatory_params
    {"user_id"=>String, "first_name"=>String, "last_name"=>String, "pin"=>String}
end

end
