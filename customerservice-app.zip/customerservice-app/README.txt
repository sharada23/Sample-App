# README
SystemConf Used:
 - ubuntu 14.04

Rails Version:
 - 5.0.1

Ruby Version:
 - 2.2.6

MySql Database Version:
 - 14.14

Server:
 - nginx with passenger

Front End:
 - AngularJS

AngularJS location:
 - ./public/index.html

API Documentation location:
 - ./API_documentation

Installation Guide:
 - ./Installation 

Server Settings files are in below location:
 - ./ServerSettings

Assumptions is as below:
 - Admin users are created at the backend running curl command and roles are privileges are created and assigned for admin before login
 - Only admin can create agents. Couldnt complet it on portal
 - Once a ticket is created by user, by default it will appear as red(yet to process by agents).
 - once the ticket is update by agents tickets turn to green.



=====Execute below curl call to create admin=====

Admin creation:
curl -i -H "Content-Type: application/json" -H "Accept: application/json" -X POST -d '{"auth_token":"HRo3RZM5zT7HoyKs318g","agents":{"user_id":"abc", "first_name":"shravan", "last_name":"chandrashekharaiah", "pin":"welcome"}}' 'http://localhost/agents'

Create privileges:
1. Privilege one
curl -i -H "Content-Type: application/json" -H "Accept: application/json" -X POST -d '{"auth_token":"HRo3RZM5zT7HoyKs318g","privileges":{"title":"user_register"} }' 'http://localhost/privileges'

2. Privilege two
curl -i -H "Content-Type: application/json" -H "Accept: application/json" -X POST -d '{"auth_token":"HRo3RZM5zT7HoyKs318g","privileges":{"title":"tickets_update"} }' 'http://localhost/privileges'

Execute below in rails console:
r = Role.new
r.tile = "admin"
r.save
r.privileges = Privileges.all



