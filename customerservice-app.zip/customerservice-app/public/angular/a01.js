var app = angular.module("app", [])

app.controller("emp", ["$scope", function($scope){
	$scope.msg = "this is third message";
}]);

app.directive('myInfoMsg', function(){
	return {
		templateUrl: "my-info-msg.html"
	};

});
