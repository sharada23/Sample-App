var app = angular.module("app", ['ngRoute']);

app.config(["$routeProvider", function($routeProvider){
	$routeProvider
	.when('/users', {
        templateUrl: "views/userLogin.html",
		controller: "userControllers"
    })
	.when('/register', {
        templateUrl: "views/userRegister.html",
        controller: "userControllers"
    })
	.when('/user_sessions/:session_id/tickets', {
        templateUrl: "views/userTickets.html",
        controller: "ticketControllers"
    })
	.when('/ticket_form', {
        templateUrl: "views/newTickets.html",
        controller: "ticketControllers"
    })
	.when('/post/user_sessions/:session_id/tickets', {
        templateUrl: "views/newTickets.html",
        controller: "ticketControllers"
    })
	.when('/agents', {
        templateUrl: "views/agentLogin.html",
		controller: "agentControllers"
    })
	.when('/tickets', {
        templateUrl: "views/listTickets.html",
        controller: "ticketControllers"
    })
	.when('/sessions/:session_id/tickets/:ticket_id/resolve', {
        templateUrl: "views/updateTickets.html",
        controller: "ticketControllers"
    })
	.when('/tickets/:ticket_id/process', {
//		template: "<strong>update it</strong>"
        templateUrl: "views/updateTicket.html",
        controller: "ticketControllers"
    })
	.when('/', {
        template: "<strong>click any link from left pannels</strong>"
    })
	.otherwise({
        template: "<strong>No content available</strong>"
    })
}]);


