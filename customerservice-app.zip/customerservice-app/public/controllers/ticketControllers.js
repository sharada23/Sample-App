app.controller("ticketControllers", ["$scope", "ticketActions", "$routeParams", "$location", "$route", function($scope, ticketActions, $routeParams, $location, $route){
	
	console.log('----inside ticketControllers----')
	$scope.result = ""
	$scope.list = false	
	var redirect_url = ""

	console.log('+++++')
	console.log($routeParams)
	if ($routeParams.agent_id){
		ticketActions.getAllTicket().then(function(result){
			console.log("----inside getAllTicket ----")
			$scope.result = result.data	
			$scope.allTickets = $scope.result.tickets
		});
	}

	if ($routeParams.session_id != undefined){
			console.log("----inside getUserTicket ----")
		$scope.session_id = $routeParams.session_id;
		ticketActions.getUserTicket($routeParams.session_id).then(function(result){
			$scope.result = result.data
			$scope.allTickets = $scope.result.tickets
			console.log($scope.allTickets)
		})
	}


	$scope.updateTicket = function(){
		console.log('---calling udpate API---')
		ticketActions.updateTicket($routeParams.session_id, $routeParams.ticket_id, $scope.comments).then(function(result){
			$scope.result = result.data
			redirect_url = "/tickets?agent_id=" + $scope.session_id
			$location.url(redirect_url)
		});
	}


	$scope.newTicket = function(){
		redirect_url = "/post/user_sessions/" + $scope.session_id + "/tickets"
		$location.url(redirect_url)

	}

	$scope.createTicket = function(){
		console.log("---- inside createTicket ----")
		ticketActions.createTicket($scope.session_id, $scope.title, $scope.description).then(function(result){
			$scope.result = result.data
			redirect_url = "/user_sessions/" + $scope.session_id + "/tickets"
			$location.url(redirect_url)
		})

	}	


}]);



