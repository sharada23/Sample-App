app.controller("userControllers", ["$scope", "userLogin", "$location", function($scope, userLogin, $location){
	$scope.user_id = "";
	$scope.pin = "";
	$scope.loading = false;
	$scope.result = ""	

	var redirect_url = ""

	$scope.login = function(){
		$scope.loading = true;	
		userLogin.signIn($scope.user_id, $scope.pin).then(function(result){
			$scope.result = result.data
			$scope.loading = false;	
			redirect_url = "/user_sessions/" + $scope.result.session_id + "/tickets"
			$location.url(redirect_url)
		});
	}

	$scope.callRegister = function(){
		$location.url('/register')
	}

	$scope.register = function(){
        $scope.loading = true;
        userLogin.register($scope.user_id, $scope.pin, $scope.first_name, $scope.last_name).then(function(result){
            $scope.result = result.data
			console.log($scope.result)
            $scope.loading = false;
            redirect_url = "/user_sessions/" + $scope.result.session_id + "/tickets"
            $location.url(redirect_url)
        });
	}


/*
	$scope.userTicket = function(){
		console.log('---inside userTicket------')
		redirect_url = "/post/user_sessions/" + $scope.session_id + "/tickets"
		$location.url(redirect_url)
	}
*/


}]);
