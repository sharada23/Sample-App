app.controller("agentControllers", ["$scope", "agentLogin", "$location", "ticketActions", function($scope, agentLogin, $location, ticketActions){
    $scope.user_id = "shravan@saranyu.in";
    $scope.pin = "welcome";
    $scope.loading = false;
    $scope.result = ""

    var redirect_url = ""


    $scope.login = function(){
		console.log('--inside agentControllers ----')
        $scope.loading = true;
        agentLogin.signIn($scope.user_id, $scope.pin).then(function(result){

            $scope.result = result.data
			$scope.session_id = $scope.result.session_id
            $scope.loading = false;
            redirect_url = "/tickets?agent_id=" + $scope.session_id
            $location.url(redirect_url)
        });
    }
/*
    $scope.userTicket = function(){
        console.log('---inside userTicket------')
        redirect_url = "/post/user_sessions/" + $scope.session_id + "/tickets"
        $location.url(redirect_url)
    }
*/


}]);
