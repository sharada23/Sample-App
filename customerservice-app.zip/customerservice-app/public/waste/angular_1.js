var app = angular.module("app", []);

app.controller("userType", [ "$scope", function($scope){
	$scope.user_type = "";
	$scope.available_options = ["users", "agents"];
	$scope.default_page = "login";
} ] );


//app.controller("userController", [ "$scope", "$registerService", function($scope, registerService){
app.controller("userController", [ "$scope", "registerService", "loginService", "userTicketService", "ticketService", function($scope, registerService, loginService, userTicketService, ticketService){

//  variabels
	$scope.user_id = "pooran@gmail.com";
	$scope.first_name = "pooran";
	$scope.last_name = "chan";
	$scope.pin = "welcome";
	$scope.session = "empty";
	$scope.tickets = "";	
	$scope.response = "result";


    $scope.ticket_resp = "";
    $scope.create_user_ticket = "no";
//methods
	$scope.register = function(){
		registerService.sign_up($scope.user_id, $scope.first_name, $scope.last_name, $scope.pin, function(result){
			$scope.response = result;
			$scope.session = $scope.session_id
		});
		
	};	

	$scope.login = function(){
		loginService.sign_in($scope.user_id, $scope.pin, $scope.user_type, function(result){
			$scope.response = result;
			$scope.session = $scope.response.session_id

			$scope.tickets = userTicketService.getTickets($scope.session, function(result){
				$scope.tickets = result.tickets;
			});

//			alert($scope.session);
		});
	};	

	$scope.reg_page = function(){
		$scope.default_page = "register";
	};	
	
	$scope.login_page = function(){
		$scope.default_page = "login";
	};	

///*

    $scope.save_ticket = function(){
    	$scope.title = "hello";
        ticketService.createTicket($scope.title, $scope.category, $scope.desc, $scope.session, function(result){
            $scope.ticket_resp = result.message;
            debugger;
        });

    };

    $scope.set_ticket_flag = function(){

    	$scope.category = "general";
    	$scope.desc = "description";
        $scope.create_user_ticket = "yes";
    };
/*
	$scope.testing = function(){
		$scope.title = "hello";
		debugger;
	};
*/
//*/

} ] );


app.service("registerService", ["$http", "$log", function( $http, $log){
//	$httpProvider.defaults.headers.post = {'Content-Type': 'application/json'}
	this.sign_up = function(user_id, f_name, l_name, pin, cb){
//		debugger;
		var data = {};
		data["users"] = {};
		data["users"]["user_id"] = user_id;
		data["users"]["first_name"] = f_name;
		data["users"]["last_name"] = l_name;
		data["users"]["pin"] = pin;

		$http({
			url: "http://localhost/users",
			method: "POST",
			data: data,
			headers: {'Content-Type': 'application/json'}
		}).then(function(resp){
			$log.log(resp.data);
			cb(resp.data)
		}, function(resp){
			$log.error(resp.data);
		} );

		$log.log(data);
	};

}]);

app.service("loginService", ["$http", "$log", function($http, $log){
	this.sign_in = function(user_id, pin, user_type, cb){

	var route = "";
	if (user_type == "agents"){
		route = "sessions"
	}else{
		route = "user_sessions"
	}


	var data = {}
	data[route] = {};
	data[route]["user_id"] = user_id;
	data[route]["pin"] = pin;

	var url = "http://localhost/" + route;
	$http({
		url: url,
		method: "POST",
		data: data,
		headers: {'Content-Type': 'application/json'}	
	}).then(function(resp){
		$log.log("****************");
		$log.log(resp.data);
		cb(resp.data)
	}, function(resp){
		$log.error(resp.data);
	});


	};

}]);

//------------------------TicketController---------------------
app.controller("ticketController", [ "$scope", "$log", "ticketService", function($scope, $log, ticketService){
	$scope.title = "my_title";
	$scope.category = "general";
	$scope.desc = "description";
	$scope.ticket_resp = "";
	$scope.create_user_ticket = "no";
//	$scope.title = "asdasd";	
	debugger;
//	alert("inside ticketController")
	$scope.save_ticket = function(){
		debugger;
		ticketService.createTicket($scope.title, $scope.category, $scope.desc, $scope.session, function(result){
			$scope.ticket_resp = result.message;
			debugger;
		});

	};

	$scope.set_ticket_flag = function(){
		$scope.create_user_ticket = "yes";
	};

}]);

app.service("ticketService", ["$http", "$log", function($http, $log){

	this.createTicket = function(title, category, desc, session, cb){
		debugger;
		var data = {}
		data["tickets"] = {}
		data["tickets"]["title"] = title;
		data["tickets"]["category"] = category;
		data["tickets"]["comments"] = desc;
		data["tickets"]["image"] = "";
		$log.log(data)
		debugger;
//		alert(data.tickets.title);
//		alert(session);
		$http({
			url: "http://localhost/user_sessions/" + session + "/tickets",
			method: "POST",
        	data: data,
        	headers: {'Content-Type': 'application/json'}
		}).then(function(resp){
			cb(resp.data)
		}, function(resp){
			alert(resp.data.error.message)
			debugger;
		});

	};


}]);


app.service("userTicketService", ["$http", "$log", function($http, $log){
	this.getTickets = function(session, cb){

		url = "http://localhost/user_sessions/" + session + "/tickets"

		$http({
			url: url
		}).then(function(resp){
			cb(resp.data)
		}, function(resp){
			alert(resp.data)
		})
	};

}]);


