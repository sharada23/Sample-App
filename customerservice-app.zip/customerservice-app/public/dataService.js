app.config(["userLoginProvider", function(userLoginProvider){
    userLoginProvider.config("http://localhost/")
}]);

app.provider("userLogin", function(){

    var baseurl = "";
    this.config = function(url){
        baseurl = url;
    }

    this.$get = ["$http", "$log", function($http, $log){

        var oDataService = {};

        oDataService.signIn = function(user_id, pin){

			data = {}
			data["user_sessions"] = {}
			data["user_sessions"]["user_id"] = user_id
			data["user_sessions"]["pin"] = pin

            return $http({
                url: baseurl  + "/user_sessions",
                method: "POST",
				data: data,
				headers: {'Content-Type': 'application/json'}
            });
        }


        return oDataService;
    }];

});
