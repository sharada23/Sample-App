app.config(["userLoginProvider", function(userLoginProvider){
    userLoginProvider.config("http://localhost/")
}]);

app.provider("userLogin", function(){

    var baseurl = "";
    this.config = function(url){
        baseurl = url;
    }

    this.$get = ["$http", "$log", function($http, $log){

        var oDataService = {};

        oDataService.signIn = function(user_id, pin){
			data = {}
			data["user_sessions"] = {}
			data["user_sessions"]["user_id"] = user_id
			data["user_sessions"]["pin"] = pin
            return $http({
                url: baseurl  + "user_sessions",
                method: "POST",
				data: data,
				headers: {'Content-Type': 'application/json'}
            });
        }


        oDataService.register = function(user_id, pin, first_name, last_name){
            data = {}
            data["users"] = {}
            data["users"]["user_id"] = user_id
            data["users"]["pin"] = pin
			data["users"]["first_name"] = first_name
			data["users"]["last_name"] = last_name
            return $http({
                url: baseurl  + "users",
                method: "POST",
                data: data,
                headers: {'Content-Type': 'application/json'}
            });
        }	


        return oDataService;
    }];

});
