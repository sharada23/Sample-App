app.config(["ticketActionsProvider", function(userLoginProvider){
    userLoginProvider.config("http://localhost/")
}]);

app.provider("ticketActions", function(){

    var baseurl = "";
    this.config = function(url){
        baseurl = url;
    }

    this.$get = ["$http", "$log", function($http, $log){
        var oDataService = {};

        oDataService.getUserTicket = function(session_id){
            return $http({
                url: baseurl  + "user_sessions/" + session_id + "/tickets",
                method: "GET"
            });
        }

        oDataService.getAllTicket = function(){
            return $http({
                url: baseurl + "tickets",
                method: "GET"
            });
        }

		oDataService.createTicket = function(session_id, title, description){
			data = {}
			data["tickets"] = {}
			data["tickets"]["title"] = title
			data["tickets"]["comments"] = description

			return $http({
				url: baseurl + "user_sessions/" + session_id + "/tickets",
				method: "POST",
				data: data,
				headers: {'Content-Type': 'application/json'}
			});
		}

        oDataService.updateTicket = function(session_id, ticket_id, comments){
            var data = {}
            data["tickets"] = {}
            data["tickets"]["category"] = comments
            return $http({
//                url: baseurl + "sessions/" + session_id + "/tickets/" + ticket_id + "/resolve",
                url: baseurl + "tickets/" + ticket_id + "/process",
                method: "PUT",
                data: data,
                headers: {'Content-Type': 'application/json'}
            });
        }


        return oDataService;
    }];

});
