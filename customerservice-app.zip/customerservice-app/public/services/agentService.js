app.config(["agentLoginProvider", function(agentLoginProvider){
    agentLoginProvider.config("http://localhost/")
}]);

app.provider("agentLogin", function(){

    var baseurl = "";
    this.config = function(url){
        baseurl = url;
    }

    this.$get = ["$http", "$log", function($http, $log){

        var oDataService = {};

        oDataService.signIn = function(user_id, pin){
			data = {}
			data["sessions"] = {}
			data["sessions"]["user_id"] = user_id
			data["sessions"]["pin"] = pin
            return $http({
                url: baseurl  + "sessions",
                method: "POST",
				data: data,
				headers: {'Content-Type': 'application/json'}
            });
        }


        return oDataService;
    }];

});
