Rails.application.routes.draw do
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html


	get '/sum' => "agents#sum"
	get '/sum/:a/:b' => "agents#sum"

	resources :user_sessions do 
		resources :tickets
	end

	resources :users
	resources :privileges
	get '/roles' => "roles#lists"
	get '/tickets' => "tickets#lists"
	put 'sessions/:session_id/tickets/:ticket_id/process' => "tickets#process_ticket"
	put '/tickets/:ticket_id/process' => "tickets#process_ticket"
	
	resources :agents do
	    member do
            post :register
        end
	end

	resources :sessions do

		member do 
#			put "tickets/:id/process" => "tickets#process"
			get :tickets
		end

		resources :roles do 
			member do 
				post :rights
				get :rights
			end
		end

	end



end
