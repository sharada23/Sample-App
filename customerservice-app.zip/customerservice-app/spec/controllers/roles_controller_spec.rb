require 'rails_helper'

RSpec.describe RolesController, type: :controller do

end
