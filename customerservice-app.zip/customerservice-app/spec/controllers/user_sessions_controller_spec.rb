require 'rails_helper'

RSpec.describe UserSessionsController, type: :controller do

end
