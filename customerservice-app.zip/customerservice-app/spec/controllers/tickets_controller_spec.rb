require 'rails_helper'

RSpec.describe TicketsController, type: :controller do

end
