require 'rails_helper'

RSpec.describe AgentsController, type: :controller do


end
