class CreateRights < ActiveRecord::Migration[5.0]
  def change
    create_table :rights do |t|
		t.belongs_to :role, index: true
		t.belongs_to :privilege, index: true
      	t.timestamps
    end
  end
end
