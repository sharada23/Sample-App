class CreateAgents < ActiveRecord::Migration[5.0]
  def change
    create_table :agents do |t|
        t.string :user_id, :uniqueness => true
		t.string :agent_id, :uniqueness => true
        t.string :pin
        t.string :first_name
        t.string :last_name
        t.string :encrypted_password
        t.string :password_salt

      	t.timestamps
    end
  end
end
