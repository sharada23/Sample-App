class CreateAgentRoles < ActiveRecord::Migration[5.0]
  def change
    create_table :agent_roles do |t|

		t.belongs_to :role, index: true
		t.belongs_to :agent, index: true
      	t.timestamps
    end
  end
end
