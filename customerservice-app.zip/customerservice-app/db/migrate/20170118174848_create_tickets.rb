class CreateTickets < ActiveRecord::Migration[5.0]
  def change
    create_table :tickets do |t|
		t.string :title
		t.string :image
		t.string :category
		t.string :comments
		t.boolean :status, :default => false
		t.string :agent_id
	
		t.belongs_to :user
      t.timestamps
    end
  end
end
